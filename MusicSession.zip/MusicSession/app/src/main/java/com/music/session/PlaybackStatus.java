package com.music.session;

public enum PlaybackStatus {
    PLAYING,
    PAUSED
}
